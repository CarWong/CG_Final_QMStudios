=============================================================
CG Final Rubbish Rush 
=============================================================
Abdalla Mohamed (100795120)
Angelina Ratchkov (100740576)
Carolyn Wong (100781520)
Joshua Humphrey (100733209)
Nathan Woo (100787454)
